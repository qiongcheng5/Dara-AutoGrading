from extensions import ma
from models.models import PromptContext, StudentQuestion, Answer, Feedback

class PromptContextSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = PromptContext

class StudentQuestionSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = StudentQuestion

    prompt_context = ma.Nested(PromptContextSchema)

class AnswerSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Answer

class FeedbackSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Feedback