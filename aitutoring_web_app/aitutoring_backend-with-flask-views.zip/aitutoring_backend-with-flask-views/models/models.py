from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing_extensions import Annotated
from sqlalchemy import func
import datetime
from extensions import db


intpk = Annotated[int, mapped_column(primary_key=True)]
timestamp = Annotated[
    datetime.datetime,
    mapped_column(nullable=False, server_default=func.CURRENT_TIMESTAMP()),
]


class PromptContext(db.Model):
    id: Mapped[int] = mapped_column(db.Integer, primary_key=True)
    email: Mapped[str] = mapped_column(db.String(50))
    canvas_crn: Mapped[int] = mapped_column(db.BigInteger)
    item_title: Mapped[str] = mapped_column(db.String(50))
    prompt_context: Mapped[str] = mapped_column(db.Text)

    def __init__(self, email, canvas_crn, item_title, prompt_context):
        self.email = email
        self.canvas_crn = canvas_crn
        self.item_title = item_title
        self.prompt_context = prompt_context

    def __repr__(self):
        return f'<Context {self.canvas_crn} : {self.item_title}>'

    """ Get context for a given CRN and Canvas item.
    """
    @staticmethod
    def get_item_context(canvas_crn, item_title):
        filter_data = { "canvas_crn": canvas_crn, "item_title": item_title }
        context = PromptContext.query.filter_by(**filter_data).first()

        return context

    """ Get a list of unique CRNs
    """
    @staticmethod
    def get_unique_crns():
        query = PromptContext.query.with_entities(PromptContext.canvas_crn).distinct().all()
        return [row[0] for row in query]

    """ Get a list of canvas items for a CRN
    """
    @staticmethod
    def get_canvas_items(crn):
        items = PromptContext.query.filter_by(canvas_crn=crn).all()
        print(items)
        return items



class StudentQuestion(db.Model):
    id: Mapped[int] = mapped_column(db.Integer, primary_key=True)
    email: Mapped[str] = mapped_column(db.String(50))
    prompt_context_id: Mapped[int | None] = mapped_column(db.ForeignKey(PromptContext.id), nullable=True)
    prompt_context: Mapped["PromptContext"] = relationship()
    question: Mapped[str] = mapped_column(db.Text)
    created_at: Mapped[timestamp]
    answer: Mapped["Answer"] = relationship(back_populates="question")

    def __init__(self, email, prompt_context_id, question):
        self.email = email
        self.prompt_context_id = prompt_context_id
        self.question = question

    def __repr__(self):
        return f'<Question {self.question}>'


class Answer(db.Model):
    id: Mapped[int] = mapped_column(db.Integer, primary_key=True)
    question_id: Mapped[int] = mapped_column(db.ForeignKey(StudentQuestion.id))
    answer: Mapped[str] = mapped_column(db.Text)
    question: Mapped["StudentQuestion"] = relationship(back_populates="answer")

    def __init__(self, question_id, answer):
        self.question_id = question_id
        self.answer = answer

    def __repr__(self):
        return f'<Answer {self.answer[:20]}...>'


class Feedback(db.Model):
    id: Mapped[int] = mapped_column(db.Integer, primary_key=True)
    answer_id: Mapped[int] = mapped_column(db.ForeignKey(Answer.id))
    feedback: Mapped[str] = mapped_column(db.Text)

    def __init__(self, answer_id, feedback):
        self.answer_id = answer_id
        self.feedback = feedback

    def __repr__(self):
        return f"<Feedback for <{self.answer_id}>: {self.feedback}"

class AutogradeInput(db.Model):
    id: Mapped[int] = mapped_column(db.Integer, primary_key=True)
    email: Mapped[str] = mapped_column(db.String(50))
    canvas_crn: Mapped[int] = mapped_column(db.BigInteger)
    session_id: Mapped[int] = mapped_column(db.BigInteger, nullable=True)
    filename: Mapped[str] = mapped_column(db.String(50))

    def __init__(self, email, canvas_crn, session_id, filename):
        self.email = email
        self.canvas_crn = canvas_crn
        self.session_id = session_id
        self.filename = filename