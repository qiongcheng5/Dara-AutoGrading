# aitutoring_backend

Backend server for the AI tutor project.

## Usage
### Python Version: `3.11.5`
### Install dependencies
```
pip install -r requirements.txt
```

### Add `.env` file
* `DATABASE_URI`: Contains the URI link to a MySQL database. Change this appropriately when deploying on cloud

URI format is: `mysql://<user>:<password>@<url>:<port>/<db>`
```
DATABASE_URI=mysql://<user>:<password>@<url>:<port>/<db>
OPENAI_API_KEY=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
```

### Create initial tables with `flask db` or with direct SQL queries:
```
flask db upgrade
```
#### SQL queries for creation of tables:
```
CREATE TABLE prompt_context (
    id INTEGER NOT NULL AUTO_INCREMENT,
    email VARCHAR(50) NOT NULL,
    canvas_crn BIGINT NOT NULL,
    item_title VARCHAR(50) NOT NULL,
    prompt_context TEXT NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE student_question (
    id INTEGER NOT NULL AUTO_INCREMENT,
    email VARCHAR(50) NOT NULL,
    prompt_context_id INTEGER NULL,
    question TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    FOREIGN KEY(prompt_context_id) REFERENCES prompt_context (id)
);

CREATE TABLE answer (
    id INTEGER NOT NULL AUTO_INCREMENT,
    question_id INTEGER NOT NULL,
    answer TEXT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY(question_id) REFERENCES student_question (id)
);

CREATE TABLE feedback (
    id INTEGER NOT NULL AUTO_INCREMENT, 
    answer_id INTEGER NOT NULL, 
    feedback TEXT NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(answer_id) REFERENCES answer (id)
);
```

### Run server
```
export FLASK_APP=app.py
flask run
```
