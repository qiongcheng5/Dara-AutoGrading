import os

os.environ["OPENAI_API_KEY"] = "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"

class Config:
    SQLALCHEMY_DATABASE_URI = "mysql://root:7PBqohUQJ1LBC2sDIx0x@containers-us-west-134.railway.app:7309/railway"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    GPT_MODEL = "gpt-3.5-turbo"
    UPLOAD_FOLDER = "uploads/"
    SECRET_KEY = "Yw30LuFxBl"
    GRADING_TIMES = 3
    
    # configuration of mail 
    MAIL_SERVER='smtp.gmail.com'
    MAIL_PORT = 465
    MAIL_USERNAME = 'aitutoruncc@gmail.com'
    MAIL_PASSWORD = 'fqtx nhdy mutb lnvo'
    MAIL_USE_TLS = False
    MAIL_USE_SSL = True