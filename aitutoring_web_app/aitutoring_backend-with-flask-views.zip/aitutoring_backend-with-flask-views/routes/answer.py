from flask import Blueprint, request, jsonify
from models.schemas import AnswerSchema, FeedbackSchema
from models.models import Answer, Feedback
from extensions import db

answer_api = Blueprint("answer", __name__)
answer_schema = AnswerSchema()
feedback_schema = FeedbackSchema()

@answer_api.route("/api/answer", methods=["POST"])
def add_question():
    question_id = request.json["question_id"]
    answer = request.json["answer"]

    answer = Answer(question_id, answer)
    db.session.add(answer)
    db.session.commit()

    return answer_schema.jsonify(answer)

@answer_api.route("/api/feedback", methods=["POST"])
def add_feedback():
    answer_id = request.json["answer_id"]
    feedback_text = request.json["feedback"]

    feedback = Feedback(answer_id, feedback_text)
    db.session.add(feedback)
    db.session.commit()

    return feedback_schema.jsonify(feedback)
