from flask import Blueprint, request, jsonify, render_template
from models.schemas import PromptContextSchema
from models.models import PromptContext
from extensions import db

context_api = Blueprint("context", __name__)
context_schema = PromptContextSchema()
context_schema_list = PromptContextSchema(many=True)

@context_api.route("/api/context", methods=["POST"])
def add_context():
    email = request.json["email"]
    canvas_crn = request.json["canvas_crn"]
    item_title = request.json["item_title"]
    prompt_context = request.json["prompt_context"]

    context = PromptContext(email, canvas_crn, item_title, prompt_context)
    db.session.add(context)
    db.session.commit()

    return context_schema.jsonify(context)


@context_api.route("/api/context", methods=["GET"])
def get_context():
    args = request.args
    canvas_crn = args.get("canvas_crn")
    item_title = args.get("item_title")

    if canvas_crn != None and item_title != None:
        context = PromptContext.get_item_context(canvas_crn, item_title)
        return context_schema.jsonify(context)
    elif canvas_crn != None and item_title == None:
        context = PromptContext.get_canvas_items(canvas_crn)
        return context_schema_list.jsonify(context)

    return None

@context_api.route("/instructor", methods=["GET", "POST"])
def instructor():
    context = None
    if request.method == "POST":
        email = request.form["email"]
        canvas_crn = request.form["canvas_crn"]
        item_title = request.form["item_title"]
        prompt_context = request.form["prompt_context"]

        context = PromptContext(email, canvas_crn, item_title, prompt_context)
        db.session.add(context)
        db.session.commit()
        
    return render_template("instructor.html", context=context)
    