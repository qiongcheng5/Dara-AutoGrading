from flask import Blueprint, request, jsonify, render_template, session
from models.schemas import StudentQuestionSchema
from models.models import StudentQuestion, PromptContext
from extensions import db
import markdown

question_api = Blueprint("question", __name__)
question_schema = StudentQuestionSchema()

@question_api.route("/api/question", methods=["POST"])
def add_question():
    email = request.json["email"]
    try:
        prompt_context_id = request.json["prompt_context_id"]
    except KeyError:
        prompt_context_id = None
    question = request.json["question"]

    question_obj = StudentQuestion(email, prompt_context_id, question)
    db.session.add(question_obj)
    db.session.commit()

    return question_schema.jsonify(question_obj)

@question_api.route("/student", methods=["GET", "POST"])
async def student():
    crns = PromptContext.get_unique_crns()
    items = []
    if len(crns) > 0:
        items = PromptContext.get_canvas_items(crns[0])
    return render_template("student.html", crns=crns, items=items)