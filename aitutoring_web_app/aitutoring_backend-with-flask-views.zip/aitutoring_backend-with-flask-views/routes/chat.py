from flask import Blueprint, request, jsonify
import openai
from config import Config

chat_api = Blueprint("chat", __name__)

@chat_api.route("/api/chat", methods=["POST"])
def chat():
    print(request.data, request.json)
    messages = request.json["messages"]
    completion = openai.ChatCompletion.create(
        model=Config.GPT_MODEL,
        messages=messages
    )

    return jsonify(completion.choices[0].message)