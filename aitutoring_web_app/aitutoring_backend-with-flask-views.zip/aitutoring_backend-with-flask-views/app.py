from flask import Flask, render_template
from config import Config
from routes import context, question, answer, chat, autograder
from extensions import db, ma, migrate, mail
from models.models import *
from flask_mail import Message
import os


def create_app(config):
    app = Flask(__name__)
    app.config.from_object(config)
    register_extensions(app)
    register_blueprints(app)

    return app

def register_extensions(app):
    db.init_app(app)
    ma.init_app(app)
    migrate.init_app(app, db)
    mail.init_app(app)

def register_blueprints(app):
    app.register_blueprint(context.context_api)
    app.register_blueprint(question.question_api)
    app.register_blueprint(answer.answer_api)
    app.register_blueprint(chat.chat_api)
    app.register_blueprint(autograder.autograde_api)

def create_folder(folder_path):
    # Check if the folder exists
    if not os.path.exists(folder_path):
        # If it doesn't exist, create it
        os.makedirs(folder_path)
        print(f"Folder '{folder_path}' created successfully.")
    else:
        print(f"Folder '{folder_path}' already exists.")


app = create_app(Config)
create_folder("uploads/")
create_folder("downloads/")

@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)