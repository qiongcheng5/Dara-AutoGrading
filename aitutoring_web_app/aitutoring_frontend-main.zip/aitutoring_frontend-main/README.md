# AI Tutoring Project

This webapp creates a simple interface for an LLM to be used as an AI tutoring assistant. The LLM will be guided by the boundaries set by instructors for every class/assignment.

## Usage
### Install dependencies
```
npm install
```

### Add `.env` file
* `REACT_APP_API_BASE_URL`: Contains URL of the backend server. In development mode, it will be `http://localhost:5000`. Make sure to change this when deploying on cloud.
```
REACT_APP_API_BASE_URL=http://localhost:5000
```

### Run
```
npm start
```
