import { useState } from "react";
import Chat from "../components/Chat";
import { Message } from "../utils/types";
import Layout from "../components/Layout";
import chatService from "../services/chat";

function Student() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [email, setEmail] = useState("");
  const [CRN, setCRN] = useState("");
  const [canvasItem, setCanvasItem] = useState("");
  const [question, setQuestion] = useState("");
  const [firstRun, setFirstRun] = useState(true);
  const [contextId, setContextId] = useState<number | null>(null);

  const sendMessage = async () => {
    if (email.trim() === "" || canvasItem.trim() == "" || CRN.trim() === "") {
      alert("Please fill all inputs");
      return;
    }
    let messagesPayload: Array<Message> = [];
    const message: Message = { role: "user", content: question };
    let context;
    if (firstRun) {
      context = await chatService.getContext(Number(CRN), canvasItem);
      if (Object.keys(context).length > 0) {
        setContextId(context.id);
        const systemMessage: Message = { role: "system", content: context.prompt_context };
        setMessages(prevMessages => [...prevMessages, systemMessage]);
        messagesPayload = [systemMessage];
      }
      setFirstRun(false);
    }
    messagesPayload = [...messagesPayload, ...messages, message];
    setMessages(prevMessages => [...prevMessages, message]);
    const response = await chatService.chat(messagesPayload);
    setMessages(prevMessages => [...prevMessages, response.choices[0].message]);

    const loggedQuestion = await chatService.logQuestion(contextId ? contextId : context.id, email, question);
    await chatService.logAnswer(loggedQuestion.id, response.choices[0].message.content);
  }

  return (
    <Layout>
      <div>
        <p className="py-4">
          Write down your concern about a computer science course and ask a
          question.
        </p>
        <p>
          <span className="has-text-weight-bold">For example: </span>I have a
          problem with object-oriented programming in Python. Please give me an
          example.
        </p>

        <div className="my-4">
          <div className="field">
            <label className="label">UNCC Email</label>
            <div className="control">
              <input
                className="input"
                type="email"
                placeholder="email@uncc.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="field">
            <label className="label">Canvas Class CRN</label>
            <div className="control">
              <input
                className="input"
                type="number"
                placeholder="e.g 200353"
                value={CRN}
                onChange={(e) => setCRN(e.target.value)}
                required={true}
              />
            </div>
          </div>

          <div className="field">
            <label className="label">Canvas Item</label>
            <div className="control">
              <input
                className="input"
                type="text"
                placeholder="e.g Lab: Unix/Linux Command Practices"
                value={canvasItem}
                onChange={(e) => setCanvasItem(e.target.value)}
              />
            </div>
          </div>

          <Chat messages={messages} />

          <label className="label">Question</label>
          <div className="field">
            <div className="control">
              <textarea
                className="textarea"
                placeholder="Send a message"
                rows={2}
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
              />
              <div className="control is-flex is-justify-content-center">
                <button className="button is-primary is-medium m-4" onClick={sendMessage}>
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default Student;
