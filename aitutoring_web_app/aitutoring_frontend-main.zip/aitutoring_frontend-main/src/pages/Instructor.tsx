import { useState } from "react";
import Layout from "../components/Layout";
import chatService from "../services/chat";

function Instructor() {
  const [email, setEmail] = useState("");
  const [CRN, setCRN] = useState("");
  const [canvasItem, setCanvasItem] = useState("");
  const [context, setContext] = useState("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const response = await chatService.saveContext(
      email,
      Number(CRN),
      canvasItem,
      context
    );
    alert(
      `Context saved successfully!\n${response.canvas_crn} - ${response.item_title}: ${response.prompt_context}`
    );
    setEmail("");
    setCRN("");
    setCanvasItem("");
    setContext("");
  };

  return (
    <Layout>
      <p className="py-4">Enter the prompt context for a class/canvas item.</p>

      <div className="my-4">
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label className="label">UNCC Email</label>
            <div className="control">
              <input
                className="input"
                type="email"
                placeholder="email@uncc.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required={true}
              />
            </div>
          </div>

          <div className="field">
            <label className="label">Canvas Class CRN</label>
            <div className="control">
              <input
                className="input"
                type="number"
                placeholder="e.g 200353"
                value={CRN}
                onChange={(e) => setCRN(e.target.value)}
                required={true}
              />
            </div>
          </div>

          <div className="field">
            <label className="label">Canvas Item</label>
            <div className="control">
              <input
                className="input"
                type="text"
                placeholder="e.g Lab: Unix/Linux Command Practices"
                value={canvasItem}
                onChange={(e) => setCanvasItem(e.target.value)}
                required={true}
              />
            </div>
          </div>

          <div className="field">
            <label className="label">Prompt Context</label>
            <textarea
              className="textarea"
              placeholder="Enter prompt context for this canvas item"
              value={context}
              onChange={(e) => setContext(e.target.value)}
              required={true}
            />
            <button className="button is-primary my-4" type="submit">
              Submit
            </button>
          </div>
        </form>
      </div>
    </Layout>
  );
}

export default Instructor;
