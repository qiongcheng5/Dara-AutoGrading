import { PropsWithChildren } from "react";
import { Link } from "react-router-dom";

function Layout(props: PropsWithChildren) {
  return (
    <section className="section">
      <div className="container is-max-desktop">
        <h1 className="title is-1 has-text-centered">AI Tutor</h1>
        {window.location.pathname === "/instructor"  && (
          <Link to={"/"}>
            <button className="button is-ghost">Go Back</button>
          </Link>
        )}
        {props.children}
      </div>
    </section>
  );
}

export default Layout;
