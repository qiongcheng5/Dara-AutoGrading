import { Message } from "../utils/types";
import ReactMarkdown from "react-markdown";

function MessageComponent({ role, content }: Message) {
  if (role === "system") return <></>;
  const logoPath = role === "user" ? "/student.png" : "/robot.png";
  return (
    <div
      className={`is-flex my-1 p-4 ${
        role === "user"
          ? "has-background-light"
          : "has-background-success-light"
      }`}
    >
      <div className="is-flex-shrink-0">
        <img src={logoPath} width={48} height={48} />
      </div>
      <div>
        <div className="ml-6">
          <ReactMarkdown>{content}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
}

export default MessageComponent;
