import { MessagesProps } from "../utils/types";
import Message from "./Message";

function Chat({ messages }: MessagesProps) {
  return (
    <div>
      {messages.map(m => <Message key={m.content.slice(0, 20)} role={m.role} content={m.content} />)}
    </div>
  )
}

export default Chat;