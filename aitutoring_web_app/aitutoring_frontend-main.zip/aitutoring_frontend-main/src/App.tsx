import React, { useState } from "react";
import "bulma/css/bulma.min.css";
import { Link } from "react-router-dom";
import Layout from "./components/Layout";

function App() {
  return (
    <Layout>
      <div>
        <p className="subtitle">
          Set context for the AI as an instructor. To use the AI for tutoring,
          login as student.
        </p>

        <div className="container buttons are-large is-justify-content-center py-6">
          <Link to="instructor">
            <button className="button is-light">Instructor</button>
          </Link>
          <Link to="student">
            <button className="button is-dark">Student</button>
          </Link>
        </div>
      </div>
    </Layout>
  );
}

export default App;
