export type Message = {
  role: string;
  content: string;
}

export type MessagesProps = {
  messages: Message[];
}