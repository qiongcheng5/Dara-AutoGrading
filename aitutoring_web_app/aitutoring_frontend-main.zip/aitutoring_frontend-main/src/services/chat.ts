import axios from "axios";
import { Message } from "../utils/types";

const BASE_URL: string | undefined = process.env.REACT_APP_API_BASE_URL;

const chat = async (messages: Array<Message>) => {
  const response = await axios.post(`${BASE_URL}/api/chat`, {
    messages
  });
  return response.data;
};

const saveContext = async (
  email: string,
  canvas_crn: number,
  item_title: string,
  prompt_context: string
) => {
  const response = await axios.post(`${BASE_URL}/api/context`, {
    email,
    canvas_crn,
    item_title,
    prompt_context,
  });
  return response.data;
};

const getContext = async (canvas_crn: number, item_title: string) => {
  const response = await axios.get(`${BASE_URL}/api/context`, {
    params: { canvas_crn, item_title },
  });
  return response.data;
};

const logQuestion = async (prompt_context_id: number | null, email: string, question: string) => {
  const response = await axios.post(`${BASE_URL}/api/question`, {
    email,
    prompt_context_id,
    question
  });
  return response.data;
}

const logAnswer = async (question_id: number, answer: string) => {
  const response = await axios.post(`${BASE_URL}/api/answer`, {
    question_id,
    answer
  });
  return response.data;
}

export default { chat, saveContext, getContext, logQuestion, logAnswer };
